from a_comparison import index_align_str, aligned_whole_list, x_y_type
from b_general_translation_relations import en_transrelation
import os
from test2 import min_edit_distance
import matplotlib.pyplot as plt


def en_list(path):
    list5 = []
    list1 = index_align_str(path)
    list2 = aligned_whole_list(list1)
    list3 = x_y_type(list2)
    # print(list3)
    list4 = en_transrelation(list3)
    for sent in list4:
        list5.append(sorted(sent))

    return list5


list_mt_edu = en_list("/Users/zhoujie/Desktop/MT_aln/education-all.aln")
list_ht_edu = en_list("/Users/zhoujie/Desktop/HT_aln/education-all.aln")
list_mt_law = en_list("/Users/zhoujie/Desktop/MT_aln/laws-all.aln")
list_ht_law = en_list("/Users/zhoujie/Desktop/HT_aln/laws-all.aln")
list_mt_micro = en_list("/Users/zhoujie/Desktop/MT_aln/microblog-all.aln")
list_ht_micro = en_list("/Users/zhoujie/Desktop/HT_aln/microblog-all.aln")
list_mt_news = en_list("/Users/zhoujie/Desktop/MT_aln/news-all.aln")
list_ht_news = en_list("/Users/zhoujie/Desktop/HT_aln/news-all.aln")
list_mt_official = en_list("/Users/zhoujie/Desktop/MT_aln/officialDoc-all.aln")
list_ht_official = en_list("/Users/zhoujie/Desktop/HT_aln/officialDoc-all.aln")
list_mt_science = en_list("/Users/zhoujie/Desktop/MT_aln/science-all.aln")
list_ht_science = en_list("/Users/zhoujie/Desktop/HT_aln/science-all.aln")
list_mt_sa = en_list("/Users/zhoujie/Desktop/MT_aln/scientificArticle-all.aln")
list_ht_sa = en_list("/Users/zhoujie/Desktop/HT_aln/scientificArticle-all.aln")
list_mt_spoken = en_list("/Users/zhoujie/Desktop/MT_aln/spoken-all.aln")
list_ht_spoken = en_list("/Users/zhoujie/Desktop/HT_aln/spoken-all.aln")
list_mt_subtitle = en_list("/Users/zhoujie/Desktop/MT_aln/subtitles-all.aln")
list_ht_subtitle = en_list("/Users/zhoujie/Desktop/HT_aln/subtitles-all.aln")


def edit_distance(MT_aln, HT_aln):
    edit_distance_list = []
    for sent_MT, sent_HT in zip(MT_aln,HT_aln):
        edit_distance = min_edit_distance(sent_MT,sent_HT)
        edit_distance_list.append(edit_distance)
    return edit_distance_list

data1 = edit_distance(list_mt_edu, list_ht_edu)
data2 = edit_distance(list_mt_law, list_ht_law)
data3= edit_distance(list_mt_micro, list_ht_micro)
data4 = edit_distance(list_mt_news, list_ht_news)
data5 = edit_distance(list_mt_official, list_ht_official)
data6 = edit_distance(list_mt_science, list_ht_science)
data7 = edit_distance(list_mt_sa, list_ht_sa)
data8 = edit_distance(list_mt_spoken, list_ht_spoken)
data9 = edit_distance(list_mt_sa, list_ht_subtitle)


labels = ["edit_distance"]
colors = [(202 / 255., 96 / 255., 17 / 255.), (255 / 255., 217 / 255., 102 / 255.),
          (137 / 255., 128 / 255., 68 / 255.)]
# 绘制箱型图
# patch_artist=True-->箱型可以更换颜色，positions=(1,1.4,1.8)-->将同一组的三个箱间隔设置为0.4，widths=0.3-->每个箱宽度为0.3
bplot1 = plt.boxplot(data1, patch_artist=True, labels=labels, positions=(1,), widths=0.3)
for patch, color in zip(bplot1['boxes'], colors):
    patch.set_facecolor(color)

bplot2 = plt.boxplot(data2, patch_artist=True, labels=labels, positions=(2.5,), widths=0.3)
for patch, color in zip(bplot2['boxes'], colors):
    patch.set_facecolor(color)

bplot3 = plt.boxplot(data3, patch_artist=True, labels=labels, positions=(4, ), widths=0.3)
for patch, color in zip(bplot3['boxes'], colors):
    patch.set_facecolor(color)

bplot4 = plt.boxplot(data4, patch_artist=True, labels=labels, positions=(5.5,), widths=0.3)
for patch, color in zip(bplot4['boxes'], colors):
    patch.set_facecolor(color)

bplot5 = plt.boxplot(data5, patch_artist=True, labels=labels, positions=(7, ), widths=0.3)
for patch, color in zip(bplot5['boxes'], colors):
    patch.set_facecolor(color)

bplot6 = plt.boxplot(data6, patch_artist=True, labels=labels, positions=(8.5,), widths=0.3)
for patch, color in zip(bplot6['boxes'], colors):
    patch.set_facecolor(color)

bplot7 = plt.boxplot(data7, patch_artist=True, labels=labels, positions=(10, ), widths=0.3)
for patch, color in zip(bplot7['boxes'], colors):
    patch.set_facecolor(color)

bplot8 = plt.boxplot(data8, patch_artist=True, labels=labels, positions=(11.5,), widths=0.3)
for patch, color in zip(bplot8['boxes'], colors):
    patch.set_facecolor(color)

bplot9 = plt.boxplot(data9, patch_artist=True, labels=labels, positions=(13, ), widths=0.3)
for patch, color in zip(bplot9['boxes'], colors):
    patch.set_facecolor(color)

x_position = [1, 2.5, 4, 5.5, 7, 8.5, 10, 11.5, 13]
x_position_fmt = ['education', 'laws', 'microblog', 'news', 'officialDoc', 'science', 'scientificArticle', 'spoken',
                  'subtitles']
plt.xticks([i for i in x_position], x_position_fmt)

plt.grid(linestyle="--", alpha=0.3)  # 绘制图中虚线 透明度0.3
plt.legend(bplot1['boxes'], labels, loc='upper right')  # 绘制表示框，右下角绘制
plt.savefig(fname="pic.png", figsize=[10, 10])
plt.title('translation relations edit distance')
plt.show()













