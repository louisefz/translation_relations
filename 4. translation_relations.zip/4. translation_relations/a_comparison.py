# 1.统计HT和MT使用的translation relations的情况
# 2. 统计MT 的 non-literal translation的情况
# 3. 什么情况下MT和HT标注（alignment和translation relations）的情况一致
# 4. 什么句式会导致translation relation的现象产生：语法复杂度，rare words， NER，长句子
import re
import operator

# 1.统计HT和MT使用的translation relations的情况
def index_align_str(file):
    large_list = []
    with open(file) as f:
        text = f.readlines()
        # print(text)
    for row in text:
        row=row.strip('\n')
        token_list = row.split(" ")[1:]
        large_list.append(token_list)
    if [] in large_list:
        large_list.remove([])
    return large_list
aln_MT = index_align_str("/Users/zhoujie/Desktop/MT_aln/education-all.aln")
# print(aln_MT)
# aln_HT = index_align_str("/Users/zhoujie/Desktop/HT_aln/education-all.aln")


def aligned_whole_list(aln_file):  # [(0,2), 2, "literal"] [10, "null" , "unaligned_reduction']
    single_token_index_list_new = []
    token_index_list_new = []
    sentence_list = []
    text_list = []
    re1 = "[a-z].+"
    for sentence_index_list in aln_file:
        for token_index in sentence_index_list:
            token_index_list = token_index.split(":")
            # print(token_index_list)
            for token_index in token_index_list:
                if "," in token_index:
                    single_token_index_list = token_index.split(",")
                    # print(single_token_index_list)
                    for single_token_index in single_token_index_list:
                        single_token_index_new = int(single_token_index)
                        single_token_index_list_new.append(single_token_index_new)
                    # print(single_token_index_list_new)
                    token_index_list_new.append(sorted(single_token_index_list_new))

                    single_token_index_list_new = []
                elif token_index == "":
                    token_index_list_new.append("null")
                elif re.findall(re1,token_index):
                    token_index_list_new.append(token_index)
                else:
                    token_index_new = int(token_index)
                    token_index_list_new.append(token_index_new)
            if token_index_list_new != ['null']:
                sentence_list.append(token_index_list_new)
            token_index_list_new = []
        text_list.append(sentence_list)
        # print(sentence_list)
        sentence_list = []
    # print(text_list)

    return text_list
text_list_MT = aligned_whole_list(aln_MT)
# print(text_list_MT)
# text_list_HT = aligned_whole_list(aln_HT)
# print(text_list_HT)

def x_y_type(text_list):
    sent_new= []
    text_new = []
    for sent in text_list:
        for pair in sent:
            # print(pair)
            if pair != ['null']:
                if type(pair[0]) == list and type(pair[1]) == int:
                    for p in pair[0]:
                        pair_list = [p, pair[1], pair[2]]
                        # print(pair_list)
                        sent_new.append(pair_list)
                elif type(pair[0]) == int and type(pair[1]) == list:
                    for p in pair[1]:
                        pair_list = [pair[0], p, pair[2]]
                        sent_new.append(pair_list)
                elif type(pair[0]) == list and type(pair[1]) == list:
                    for p1 in pair[0]:
                        for p2 in pair[1]:
                            pair_list = [p1, p2, pair[2]]
                            sent_new.append(pair_list)
                elif type(pair[0]) == list and pair[1] == "null":
                    for p in pair[0]:
                        pair_list = [p, pair[1], pair[2]]
                    sent_new.append(pair_list)
                elif pair[0] == "null" and type(pair[1]) == list:
                    for p in pair[1]:
                        pair_list = [pair[0], p, pair[2]]
                    sent_new.append(pair_list)
                else:
                    sent_new.append(pair)

        # print(sent_new)
        text_new.append(sent_new)
        sent_new = []
    return text_new
x_y_type_MT = x_y_type(text_list_MT)
# print(x_y_type_MT)
# # x_y_type_HT = x_y_type(text_list_HT)
# # print(x_y_type_HT)
# # #




