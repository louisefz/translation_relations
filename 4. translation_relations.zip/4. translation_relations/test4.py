# -*- coding: utf-8 -*-
from a_comparison import index_align_str, aligned_whole_list
from f_crp import crp_list, spacy_crp, crp_pair, transrelation, go_through_directory



def list_technique(path_aln,path_crp):
    list_techniq = []
    new_aln = go_through_directory(path_aln)
    new_crp = go_through_directory(path_crp)
    for aln, crp in zip(new_aln,new_crp):
        list_all_pos_HT, list_all_dep_HT = crp_pair(aln, crp)
        # print(list_all_pos_HT)
        transrelation_dict_pos_HT, transrelation_dict_dep_HT = transrelation(list_all_pos_HT, list_all_dep_HT)
        # print(transrelation_dict_pos_HT)
        if "unaligned_explicitation" in transrelation_dict_dep_HT:
            list_techniq += transrelation_dict_dep_HT["unaligned_explicitation"]
    return list_techniq
print(list_technique("/Users/zhoujie/Desktop/HT_aln","/Users/zhoujie/Desktop/HT_crp"))
