# 方法1：
# （1）找到translation relations的aln_pair, 然后再找到对应的crp_pair
# （2）即[[2,3,4,6],[4,5,6,9], literal]转化成 [["with， "the"， "exception"， "of"], ["除"， "之外"]，literal]

# 方法2：
# （1）先对对应的句子作分析
# （2）再带入aln_pair的index，进行分析


from a_comparison import index_align_str, aligned_whole_list
import os
import spacy


def crp_list(path):  # 中文英文句子列表
    en_list = []
    zh_list = []
    with open(path) as f:
        text = f.readlines()
    for i, line in enumerate(text):
        if i%3 == 1:

            en_list.append(line.replace(".\n",".").split(" "))
        elif i%3 == 2:
            zh_list.append(line.replace("。\n","。").split(" "))

    return en_list,zh_list
# en_list, zh_list_MT = crp_list("/Users/zhoujie/Desktop/MT_crp/scientificArticle-all.crp")
# print(en_list)
# print(zh_list_MT)

### pos对应，label有多少改变
def spacy_crp(path):
    en_list = []
    zh_list = []
    en_list_pos = []
    zh_list_pos = []
    en_list_dep = []
    zh_list_dep = []
    en_list_tag = []
    zh_list_tag = []

    nlp_en = spacy.load("en_core_web_md")
    nlp_zh = spacy.load("zh_core_web_md")
    with open(path) as f:
        text = f.readlines()
        for i, line in enumerate(text):
            if i % 3 == 1:
                en_list.append(line.replace(".\n", "."))
            elif i % 3 == 2:
                zh_list.append(line.replace("。\n", "。"))
    for sent_en, sent_zh in zip(en_list, zh_list):
        doc_en = nlp_en(sent_en)
        doc_zh = nlp_zh(sent_zh)
        pos_list_en = [token.pos_ for token in doc_en]
        tag_list_en = [token.tag_ for token in doc_en]
        dep_list_en = [token.dep_ for token in doc_en]
        en_list_pos.append(pos_list_en)
        en_list_tag.append(tag_list_en)
        en_list_dep.append(dep_list_en)
        pos_list_zh = [token.pos_ for token in doc_zh]
        tag_list_zh = [token.tag_ for token in doc_zh]
        dep_list_zh = [token.dep_ for token in doc_zh]
        zh_list_pos.append(pos_list_zh)
        zh_list_tag.append(tag_list_zh)
        zh_list_dep.append(dep_list_zh)
    return en_list_pos, zh_list_pos, en_list_tag, zh_list_tag, en_list_dep, zh_list_dep



en_list_pos_MT, zh_list_pos_MT, en_list_tag_MT, zh_list_tag_MT, en_list_dep_MT, zh_list_dep_MT = spacy_crp("/Users/zhoujie/Desktop/MT_crp/science-all.crp")
# print(en_list_pos_MT)
# print(zh_list_pos_MT)
# print(en_list_tag_MT)
# print(zh_list_tag_MT)
# print(en_list_dep_MT)
# print(zh_list_dep_MT)



def crp_pair(path_aln,path_crp):
    sent_lis_crp = []
    sent_lis_pos = []
    sent_lis_dep = []
    text_list_crp = []
    text_list_pos = []
    text_list_dep = []
    list_all_pos = []
    list_all_dep = []
    list1 = index_align_str(path_aln)
    aln_list = aligned_whole_list(list1)
    en_list, zh_list = crp_list(path_crp)
    en_list_pos, zh_list_pos, en_list_tag, zh_list_tag, en_list_dep, zh_list_dep = spacy_crp(path_crp)
    # print(en_list)
    # print(zh_list)
    for i, sent in enumerate(aln_list):
        for pair in sent:
            # print(pair)
            if type(pair[0]) == int and type(pair[1]) == int:
                new_crp_list = [en_list[i][pair[0]],zh_list[i][pair[1]],pair[2]]
                new_pos_list = [en_list_pos[i][pair[0]],zh_list_pos[i][pair[1]],pair[2]]
                new_dep_list = [en_list_dep[i][pair[0]],zh_list_dep[i][pair[1]],pair[2]]

            elif type(pair[0]) == list and type(pair[1]) == int:
                new_crp_list = [[en_list[i][en_index] for en_index in pair[0]],zh_list[i][pair[1]], pair[2]]
                new_pos_list = [[en_list_pos[i][en_index] for en_index in pair[0]],zh_list_pos[i][pair[1]], pair[2]]
                new_dep_list = [[en_list_dep[i][en_index] for en_index in pair[0]],zh_list_dep[i][pair[1]], pair[2]]

            elif type(pair[0]) == int and type(pair[1]) == list:
                new_crp_list = [en_list[i][pair[0]],[zh_list[i][zh_index] for zh_index in pair[1]], pair[2]]
                new_pos_list = [en_list_pos[i][pair[0]],[zh_list_pos[i][zh_index] for zh_index in pair[1]], pair[2]]
                new_dep_list = [en_list_dep[i][pair[0]],[zh_list_dep[i][zh_index] for zh_index in pair[1]], pair[2]]

            elif type(pair[0]) == list and type(pair[1]) == list:
                new_crp_list = [[en_list[i][en_index] for en_index in pair[0]], [zh_list[i][zh_index] for zh_index in pair[1]], pair[2]]
                new_pos_list = [[en_list_pos[i][en_index] for en_index in pair[0]], [zh_list_pos[i][zh_index] for zh_index in pair[1]], pair[2]]
                new_dep_list = [[en_list_dep[i][en_index] for en_index in pair[0]], [zh_list_dep[i][zh_index] for zh_index in pair[1]], pair[2]]

            elif type(pair[0]) == int and pair[1] == "null":
                new_crp_list = [en_list[i][pair[0]],"null", pair[2]]
                new_pos_list = [en_list_pos[i][pair[0]],"null", pair[2]]
                new_dep_list = [en_list_dep[i][pair[0]],"null", pair[2]]

            elif pair[0] == "null" and type(pair[1]) == int:
                new_crp_list = ["null",zh_list[i][pair[1]] , pair[2]]
                new_pos_list = ["null",zh_list_pos[i][pair[1]] , pair[2]]
                new_dep_list = ["null",zh_list_dep[i][pair[1]] , pair[2]]

            elif type(pair[0]) == list and pair[1] == "null":
                new_crp_list = [[en_list[i][en_index] for en_index in pair[0]], "null", pair[2]]
                new_pos_list = [[en_list_pos[i][en_index] for en_index in pair[0]], "null", pair[2]]
                new_dep_list = [[en_list_dep[i][en_index] for en_index in pair[0]], "null", pair[2]]

            elif pair[0] == "null" and type(pair[1]) == list:
                new_crp_list = ["null",[zh_list[i][zh_index] for zh_index in pair[1]], pair[2]]
                new_pos_list = ["null",[zh_list_pos[i][zh_index] for zh_index in pair[1]], pair[2]]
                new_dep_list = ["null",[zh_list_dep[i][zh_index] for zh_index in pair[1]], pair[2]]
            # print(new_crp_list)
            sent_lis_crp.append(new_crp_list)

            sent_lis_pos.append(new_pos_list)
            sent_lis_dep.append(new_dep_list)
        text_list_crp.append(sent_lis_crp)
        text_list_pos.append(sent_lis_pos)
        text_list_dep.append(sent_lis_dep)
        sent_lis_crp = []
        sent_lis_pos = []
        sent_lis_dep = []
    for sent, sent_pos in zip(text_list_crp, text_list_pos):
        for pair, pair_pos in zip(sent, sent_pos):
            new_pair = [[pair[0],pair[1]],[pair_pos[0],pair_pos[1]],pair[2]]
            list_all_pos.append(new_pair)
    for sent, sent_dep in zip(text_list_crp, text_list_dep):
        for pair, pair_dep in zip(sent, sent_dep):
            new_pair = [[pair[0], pair[1]], [pair_dep[0], pair_dep[1]], pair[2]]
            list_all_dep.append(new_pair)
    return list_all_pos, list_all_dep



list_all_pos_MT, list_all_dep_MT = crp_pair("/Users/zhoujie/Desktop/MT_aln/news-all.aln", "/Users/zhoujie/Desktop/MT_crp/news-all.crp")
# print(list_all_pos_MT)

def transrelation(list_all_pos,list_all_dep):
    transrelation_dict_pos = {}
    transrelation_dict_dep = {}
    for pair in list_all_pos:
        if pair[2] not in transrelation_dict_pos:
            transrelation_dict_pos[pair[2]] = [pair[:2]]
        else:
            transrelation_dict_pos[pair[2]] += [pair[:2]]
    for pair in list_all_dep:
        if pair[2] not in transrelation_dict_dep:
            transrelation_dict_dep[pair[2]] = [pair[:2]]
        else:
            transrelation_dict_dep[pair[2]] += [pair[:2]]
    return transrelation_dict_pos, transrelation_dict_dep
transrelation_dict_pos_MT, transrelation_dict_dep_MT = transrelation(list_all_pos_MT, list_all_dep_MT)
# print(transrelation_dict_pos_MT["figurative"])
# print(transrelation_dict_dep_MT["figurative"])


g_aln = os.walk("/Users/zhoujie/Desktop/MT_aln")
g_crp = os.walk("/Users/zhoujie/Desktop/MT_crp")
def go_through_directory(path):
    file_path_list = []
    g = os.walk(path)
    for path, dir_list, file_list in g:
        for file in file_list:
            file_path = os.path.join(path, file)
            file_path_list.append(file_path)
        new_file_path_list =sorted(file_path_list)
    return new_file_path_list

file_path_list_aln_MT = go_through_directory("/Users/zhoujie/Desktop/MT_aln")
# print(file_path_list_aln_MT)
file_path_list_crp_MT = go_through_directory("/Users/zhoujie/Desktop/MT_crp")
# print(file_path_list_crp_MT)
file_path_list_aln_HT = go_through_directory("/Users/zhoujie/Desktop/HT_aln")
file_path_list_crp_HT = go_through_directory("/Users/zhoujie/Desktop/HT_crp")

# def dict_transrelations(file_path_list_aln, file_path_list_crp):
#     pos_dict = {}
#     dep_dict = {}
#     for aln,crp in zip(file_path_list_aln, file_path_list_crp):
#         # print(aln,crp)
#         list_all_pos_MT, list_all_dep_MT = crp_pair(aln, crp)
#         transrelation_dict_pos, transrelation_dict_dep = transrelation(list_all_pos_MT, list_all_dep_MT)
#         # print(transrelation_dict_pos)
#         # print(transrelation_dict_dep)
#         for k, v in transrelation_dict_pos.items():
#             if k not in pos_dict:
#                 pos_dict[k] = v
#             if k in pos_dict:
#                 pos_dict[k] += v
#         for k, v in transrelation_dict_dep.items():
#             if k not in dep_dict:
#                 dep_dict[k] = v
#             if k in dep_dict:
#                 dep_dict[k] += v
#     return pos_dict, dep_dict
#
#

# transrelation_dict_pos_MT, transrelation_dict_dep_MT = dict_transrelations(file_path_list_aln_MT, file_path_list_crp_MT)
# transrelation_dict_pos_HT, transrelation_dict_dep_HT = dict_transrelations(file_path_list_aln_HT, file_path_list_crp_HT)
#
# new_list_MT = transrelation_dict_pos_MT["equivalence"]
# print(new_list_MT)
# new_list_HT = transrelation_dict_pos_HT["equivalence"]
# print(new_list_HT)







