from a_comparison import index_align_str, aligned_whole_list
from b_general_translation_relations import overal_transrelation_text, overal_transrelation_sent
import os
import matplotlib.pyplot as plt
import matplotlib.markers


def dict_list(path):
    g = os.walk(path)
    dict_list = []
    len1 = 0
    for path, dir_list, file_list in g:
        for file in file_list:
            file_path = os.path.join(path, file)
            # print(file_path)
            list1 = index_align_str(file_path)
            list2 = aligned_whole_list(list1)
            dict1,dict2,len3 = overal_transrelation_text(list2)
            dict_list.append(dict2)
            len1 += len3
    return dict_list, len1
dict_list,len_q = dict_list("/Users/zhoujie/Desktop/MT_aln")
# print(dict_list)

def all_dict(dict_list,len_k):
    new_dict = {}
    new_dict2 = {}
    for dict in dict_list:
        for key, value in dict.items():
            if key not in new_dict:
                new_dict[key] = value
                new_dict2[key] = value/len_k

            else:
                new_dict[key] = new_dict[key] + value
                new_dict2[key] = (new_dict[key] + value) / len_k

    return new_dict, new_dict2
new_dict,new_dict2 = all_dict(dict_list,len_q)
# print(new_dict)
# print(new_dict2)


def trasrelat_genre(path):
    g = os.walk(path)
    dict_genre = {}
    dict_large = {}
    dict_new = {}
    sm_dict = {}
    lg_dict = {}
    value_all = 0
    value_dict = {}
    for path, dir_list, file_list in g:
        for file in file_list:
            file_path = os.path.join(path, file)
            if "MT" in file_path:
                file_name = file_path.replace("/Users/zhoujie/Desktop/MT_aln/","").replace(".aln","").replace("-all","")
            elif "HT" in file_path:
                file_name = file_path.replace("/Users/zhoujie/Desktop/HT_aln/","").replace(".aln","").replace("-all","")
            list1 = index_align_str(file_path)
            list2 = aligned_whole_list(list1)
            list3 = overal_transrelation_sent(list2)
            # print(list3)

            for sent_dict in list3:
                for k, v in sent_dict.items():
                    if k not in dict_genre:
                        dict_genre[k] = v
                    elif k in dict_genre:
                        dict_genre[k] = dict_genre[k] + v
            dict_large[file_name] = dict_genre
            dict_genre = {}
    # print(dict_large)
    for file_name,d in dict_large.items():
        for dd in d.values():
            value_all += dd
        for kk, dd in d.items():
            sm_dict[kk] = dd/value_all
        lg_dict[file_name] = sm_dict
        value_all = 0
        sm_dict = {}
    return lg_dict


    #     value_dict[file_name] = value_all
    #     value_all = 0
    #     print(dict_large)
    # print(value_dict)


lg_dict_MT = trasrelat_genre("/Users/zhoujie/Desktop/MT_aln")
# print(lg_dict_MT)
lg_dict_HT = trasrelat_genre("/Users/zhoujie/Desktop/HT_aln")
# print(lg_dict_HT)

def genre_scatter(lg_dict):
    dict_genre = {}
    dict_genre_large = {}
    for k, v in lg_dict.items():
        for ks, vs in v.items():
            if ks not in dict_genre:
                dict_genre[ks] = [[k,vs]]
            elif ks in dict_genre:
                dict_genre[ks] += [[k,vs]]
    genre_list = sorted([[k,sorted(v)] for k, v in dict_genre.items()])
    for genre in genre_list:
        dict_genre_large[genre[0]] = genre[1]
    # if "unspec" in dict_genre_large:
    #     for s_list in dict_genre_large["unspec"]:
    #         s_list[0]
    #


    return dict_genre_large

genre_dict_MT = genre_scatter(lg_dict_MT)
# print(genre_dict_MT)
genre_dict_HT = genre_scatter(lg_dict_HT)
# print(genre_dict_HT)

def add_zero_genre(genre_dict):
    new_dict_genre = {}
    genre_list = ['education', 'laws', 'microblog', 'news', 'officialDoc', 'science', 'scientificArticle', 'spoken', 'subtitles']
    for genre in genre_list:
        for k, v in genre_dict.items():
            if genre not in [sm[0] for sm in v]:
                v.append([genre,0])
                new_dict_genre[k] = sorted(v)
            else:
                new_dict_genre[k] = sorted(v)
    return new_dict_genre

new_dict_genre_MT = add_zero_genre(genre_dict_MT)
# print(new_dict_genre_MT)
new_dict_genre_HT = add_zero_genre(genre_dict_HT)
# print(new_dict_genre_HT)

new_uncertain = []
for sm_list1, sm_list2 in zip(new_dict_genre_HT["unspec"], new_dict_genre_HT["uncertain"]):
    # print(sm_list1)
    new_uncertain_sm = [sm_list1[0], sm_list1[1] + sm_list2[1]]
    new_uncertain.append(new_uncertain_sm)
del new_dict_genre_HT['unspec']
new_dict_genre_HT["uncertain"] = new_uncertain
# print(new_dict_genre_HT)

def dict_list(dict):
    new_list = [[k,v] for k, v in dict.items()]
    return new_list
new_list_genre_MT = dict_list(new_dict_genre_MT)
print(new_list_genre_MT)
new_list_genre_HT = dict_list(new_dict_genre_HT)
print(new_list_genre_HT)


def scatter_plot(list_genre_MT, list_genre_HT):
    for genre1, genre2 in zip(list_genre_MT, list_genre_HT):

        names = ['education', 'laws', 'microblog', 'news', 'officialDoc', 'science', 'scientificArticle', 'spoken',
                 'subtitles']
        x = range(len(names))
        # print(x)
        y1 = [sm_list[1] for sm_list in genre1[1]]
        print(y1)
        y2 = [sm_list[1] for sm_list in genre2[1]]
        print(y2)
        plt.plot(x, y1, lw=1, marker='s', label='MT')
        plt.plot(x, y2, lw=1, marker='o', label= 'HT')
        # plt.plot(x, y1, x, y2)
        plt.xticks(x, names, rotation=45)
        plt.title(genre1[0])

        plt.legend(loc='upper right')
        plt.show()

scatter_plot(new_list_genre_MT, new_list_genre_HT)






###画图
#translation relation的genre图 散点图
# literally_translated token/sentence 箱型图
