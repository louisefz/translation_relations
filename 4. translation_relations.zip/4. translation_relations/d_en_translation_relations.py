from a_comparison import index_align_str, aligned_whole_list, x_y_type
from b_general_translation_relations import en_transrelation
import os
import matplotlib.pyplot as plt

i = 0
dict_en_trs = {}
g = os.walk("/Users/zhoujie/Desktop/MT_aln")
for path, dir_list, file_list in g:
    for file in file_list:
        file_path = os.path.join(path, file)
        # print(file_path)
        list1 = index_align_str(file_path)
        list2 = aligned_whole_list(list1)
        list3 = x_y_type(list2)
        # print(list3)
        list4 = en_transrelation(list3)
        # print(list4)
        for sent in list4:
            for pair in sent:
                i += 1
                if pair[1] not in dict_en_trs:
                    dict_en_trs[pair[1]] = 1
                elif pair[1] in dict_en_trs:
                    dict_en_trs[pair[1]] += 1
print(dict_en_trs)


def literal_ratio(list4):
    k = 0
    ratio_list = []
    for sent in list4:
        for pair in sent:
            if pair[1] == "literal":
                k += 1
        literal_ratio = k/len(sent)
        ratio_list.append(literal_ratio)
        k = 0
    return ratio_list
def radio_list(path):
    large_radio_list = []
    g = os.walk(path)
    for path, dir_list, file_list in g:
        for file in file_list:
            file_path = os.path.join(path, file)
            # print(file_path)
            if "MT" in file_path:
                file_name = file_path.replace("/Users/zhoujie/Desktop/MT_aln/", "").replace(".aln", "").replace("-all", "")
            elif "HT" in file_path:
                file_name = file_path.replace("/Users/zhoujie/Desktop/HT_aln/", "").replace(".aln", "").replace("-all", "")
            list1 = index_align_str(file_path)
            list2 = aligned_whole_list(list1)
            list3 = x_y_type(list2)
            # print(list3)
            list4 = en_transrelation(list3)
            # print(list4)
            radio_list = literal_ratio(list4)
            large_radio_list.append([file_name,radio_list])
    return large_radio_list
new_large_radio_list_MT = sorted(radio_list("/Users/zhoujie/Desktop/MT_aln"))
print(new_large_radio_list_MT)
new_large_radio_list_HT = sorted(radio_list("/Users/zhoujie/Desktop/HT_aln"))
print(new_large_radio_list_HT)

def en_zh_sent_avr(zh_mt,zh_ht):
    large_list = []
    for v1, v2 in zip(zh_mt,zh_ht):
        new_list = v1[1],v2[1]
        large_list.append(new_list)
    return large_list
new_large_list = en_zh_sent_avr(new_large_radio_list_MT,new_large_radio_list_HT)
# print(new_large_list)


def box_plot(large_list):
    # data是acc中三个箱型图的参数
    data1 = large_list[0]
    # data2 是F1 score中三个箱型图的参数
    data2 = large_list[1]
    # data3 是IoU中三个箱型图的参数
    data3 = large_list[2]
    data4 = large_list[3]
    data5 = large_list[4]
    data6 = large_list[5]
    data7 = large_list[6]
    data8 = large_list[7]
    data9 = large_list[8]



    # 箱型图名称
    labels = ["ZH_MT", "ZH_HT"]
    # 三个箱型图的颜色 RGB （均为0~1的数据）
    color = [(202 / 255., 96 / 255., 17 / 255.)]
    # 绘制箱型图
    # patch_artist=True-->箱型可以更换颜色，positions=(1,1.4,1.8)-->将同一组的三个箱间隔设置为0.4，widths=0.3-->每个箱宽度为0.3
    colors = [(202 / 255., 96 / 255., 17 / 255.), (255 / 255., 217 / 255., 102 / 255.),
              (137 / 255., 128 / 255., 68 / 255.)]
    # 绘制箱型图
    # patch_artist=True-->箱型可以更换颜色，positions=(1,1.4,1.8)-->将同一组的三个箱间隔设置为0.4，widths=0.3-->每个箱宽度为0.3
    bplot1 = plt.boxplot(data1, patch_artist=True, labels=labels, positions= (1,1.5,), widths=0.3)
    for patch, color in zip(bplot1['boxes'], colors):
        patch.set_facecolor(color)

    bplot2 = plt.boxplot(data2, patch_artist=True, labels=labels, positions= (2.5,3,), widths=0.3)
    for patch, color in zip(bplot2['boxes'], colors):
        patch.set_facecolor(color)

    bplot3 = plt.boxplot(data3, patch_artist=True, labels=labels, positions= (4,4.5,), widths=0.3)
    for patch, color in zip(bplot3['boxes'], colors):
        patch.set_facecolor(color)

    bplot4 = plt.boxplot(data4, patch_artist=True, labels=labels, positions= (5.5,6,), widths=0.3)
    for patch, color in zip(bplot4['boxes'], colors):
        patch.set_facecolor(color)

    bplot5 = plt.boxplot(data5, patch_artist=True, labels=labels, positions= (7,7.5,), widths=0.3)
    for patch, color in zip(bplot5['boxes'], colors):
        patch.set_facecolor(color)

    bplot6 = plt.boxplot(data6, patch_artist=True, labels=labels, positions= (8.5,9,), widths=0.3)
    for patch, color in zip(bplot6['boxes'], colors):
        patch.set_facecolor(color)

    bplot7 = plt.boxplot(data7, patch_artist=True, labels=labels, positions= (10,10.5,), widths=0.3)
    for patch, color in zip(bplot7['boxes'], colors):
        patch.set_facecolor(color)

    bplot8 = plt.boxplot(data8, patch_artist=True, labels=labels, positions= (11.5,12,), widths=0.3)
    for patch, color in zip(bplot8['boxes'], colors):
        patch.set_facecolor(color)

    bplot9 = plt.boxplot(data9, patch_artist=True, labels=labels, positions= (13,13.5,), widths=0.3)
    for patch, color in zip(bplot9['boxes'], colors):
        patch.set_facecolor(color)

    x_position = [1, 2.5, 4,5.5,7,8.5,10,11.5,13]
    x_position_fmt = ['education', 'laws', 'microblog', 'news', 'officialDoc', 'science', 'scientificArticle', 'spoken', 'subtitles']
    plt.xticks([i + 0.8 / 2 for i in x_position], x_position_fmt)


    plt.grid(linestyle="--", alpha=0.3)  # 绘制图中虚线 透明度0.3
    plt.legend(bplot1['boxes'], labels, loc='lower right')  # 绘制表示框，右下角绘制
    plt.savefig(fname="pic.png", figsize=[10, 10])
    plt.title('literally_translated_token ratio')
    plt.show()
#
# box_plot(new_large_list)




