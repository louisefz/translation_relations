from a_comparison import index_align_str, aligned_whole_list
from b_general_translation_relations import overal_transrelation_text, overal_transrelation_sent
import os
def genre_pair(path):
    dict_new = {"literal" :0, "nonliteral":0}
    list1 = index_align_str(path)
    list2 = aligned_whole_list(list1)
    # print(list2)
    for sent in list2:
        for pair in sent:
            if pair[2] == "literal":
                dict_new["literal"] += 1
            elif pair[2] != "literal":
                dict_new["nonliteral"] += 1
    return dict_new
# dict_new = genre_pair("/Users/zhoujie/Desktop/HT_aln/subtitles-all.aln")
# print(dict_new)

g = os.walk("/Users/zhoujie/Desktop/MT_aln")
for path, dir_list, file_list in g:
    for file in file_list:
        file_path = os.path.join(path, file)
        print(file_path)
        dict_new = genre_pair(file_path)
        print(dict_new)
