with open("/Users/zhoujie/Desktop/abbre") as f:
    text_list = f.readlines()
print(text_list)
for phrase in text_list:
    new_ph_list = phrase.split(" ")
    first_abbre = new_ph_list[0]
    rest = " ".join(new_ph_list[1:])
    new_str = r"\noindent \textbf{" + first_abbre + "}" + " " + "\hspace{2cm}" + " " + rest
    print(new_str)