from a_comparison import index_align_str, aligned_whole_list
from b_general_translation_relations import overal_transrelation_text


list1 = index_align_str("/Users/zhoujie/Desktop/HT_aln/scientificArticle-all.aln")
print(list1)
list2 = aligned_whole_list(list1)
print(list2)

new_list = []
new_Sent = []
i = 1
for sent in list2:
    for pair in sent:
        new_pair = [pair[1],pair[0],pair[2]]
        new_pair2 = []
        for ele in new_pair:
            if type(ele) == list:
                new_ele = [str(e) for e in ele]
                str1 = ",".join(new_ele)
                new_pair2.append(str1)
            elif type(ele) == int:
                new_pair2.append(str(ele))
            elif ele == "null":
                new_pair2.append("")
            else:
                new_pair2.append(ele)
        print(new_pair2)
        new_str = ":".join(new_pair2)
        print(new_str)
        new_Sent.append(new_str)
    print(new_Sent)
    new_str11 = str(i) + " "+ " ".join(new_Sent) + "\n"
    new_Sent = []
    i += 1
    new_list.append(new_str11)
print(new_list)
for x in new_list:
    with open("/Users/zhoujie/Desktop/HT_aln/scientificArticle-all_new.aln", "a+") as g:
        g.write(x)






