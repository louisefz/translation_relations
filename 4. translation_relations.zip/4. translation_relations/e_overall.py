#1. token数量 en/zh
#2.token aligned 有多少

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import re
def token_number(path):
    en_sent = []
    zh_sent = []
    i = 0
    j = 0
    with open(path) as f:
        text = f.readlines()
        for i, sent in enumerate(text):
            if i%3 == 1:
                en_sent.append(sent)
            elif i%3 ==2:
                zh_sent.append(sent)
    for sent1,sent2 in zip(en_sent,zh_sent):
        new_list1_len = len(sent1.split(" "))
        i += new_list1_len
        new_list2_len = len(sent2.split(" "))
        j += new_list2_len
    return i, j

i = 0
j = 0
g = os.walk("/Users/zhoujie/Desktop/HT_crp")
for path, dir_list, file_list in g:
    for file in file_list:
        file_path = os.path.join(path, file)
        # print(file_path)
        en,zh = token_number(file_path)
        i += en
        j += zh
print(i)
print(j)


def token_sent(path):
    en_sent = []
    zh_sent = []
    en_len_list = []
    en_len = 0
    zh_len_list = []
    zh_len = 0
    i = 0
    j = 0
    with open(path) as f:
        text = f.readlines()
        for i, sent in enumerate(text):
            if i%3 == 1:
                en_sent.append(sent)
            elif i%3 ==2:
                zh_sent.append(sent)
    for en,zh in zip(en_sent,zh_sent):
        j += 1
        en_len_list.append(len(en.split(" ")))
        en_len += len(en.split(" "))
        zh_len_list.append(len(zh.split(" ")))
        zh_len += len(zh.split(" "))
        avg_en = en_len / j
        avg_zh = zh_len / j


    return en_len_list, zh_len_list, avg_en, avg_zh



g = os.walk("/Users/zhoujie/Desktop/MT_crp")
for path, dir_list, file_list in g:
    for file in file_list:
        file_path = os.path.join(path, file)
        # print(file_path)
        en_len_list, zh_len_list, avg_en, avg_zh = token_sent(file_path)
        # print(en_len_list)
        # print(zh_len_list)
        N1 = 0
        N2 = 0
        for n1, n2 in zip(en_len_list,zh_len_list):
            N1 += n1
            N2 += n2
        # print(N1)
        # print(N2)
        N1 = 0
        N2 = 0


def sent_arg(mt_path, ht_path):
    g1 = os.walk(mt_path)
    en_large = {}
    zh_large_MT ={}
    for path, dir_list, file_list in g1:
        for file in file_list:
            file_path = os.path.join(path, file)
            # print(file_path)
            file_name = file_path.replace("/Users/zhoujie/Desktop/MT_crp/","").replace(".crp","").replace("-all","")
            # print(file_name)
            en_len_list, zh_len_list, avg_en, avg_zh = token_sent(file_path)
            # print(avg_en)
            # print(avg_zh)
            # print(en_len_list)
            # print(zh_len_list)
            en_large[file_name] = en_len_list
            zh_large_MT[file_name] = zh_len_list
    g2 = os.walk(ht_path)
    zh_large_HT ={}
    for path, dir_list, file_list in g2:
        for file in file_list:
            file_path = os.path.join(path, file)
            # print(file_path)
            file_name = file_path.replace("/Users/zhoujie/Desktop/HT_crp/","").replace(".crp","").replace("-all","")
            # print(file_name)
            en_len_list, zh_len_list, avg_en, avg_zh = token_sent(file_path)
            zh_large_HT[file_name] = zh_len_list
    return en_large, zh_large_MT, zh_large_HT
en_large, zh_large_MT, zh_large_HT = sent_arg("/Users/zhoujie/Desktop/MT_crp", "/Users/zhoujie/Desktop/HT_crp")
print(en_large)
# print(zh_large_MT)
# print(zh_large_HT)
def dict_list(dict):
    large_dict = {}
    new_dict = sorted(dict.items())
    for t in new_dict:
        large_dict[t[0]] = t[1]
    return large_dict

dict_new_en =dict_list(en_large)
dict_new_MT =dict_list(zh_large_MT)
dict_new_HT =dict_list(zh_large_HT)
print(dict_new_MT)
print(dict_new_HT)



def en_zh_sent_avr(en,zh_mt,zh_ht):
    large_list = []
    for v1, v2, v3 in zip(en.values(),zh_mt.values(),zh_ht.values()):
        new_list = [v1,v2,v3]
        large_list.append(new_list)
    return large_list
new_large_list = en_zh_sent_avr(dict_new_en,dict_new_MT,dict_new_HT)
# print(new_large_list)





def box_plot(large_list):
    # data是acc中三个箱型图的参数
    data1 = large_list[0]
    # data2 是F1 score中三个箱型图的参数
    data2 = large_list[1]
    print(data2)
    # data3 是IoU中三个箱型图的参数
    data3 = large_list[2]
    data4 = large_list[3]
    data5 = large_list[4]
    data6 = large_list[5]
    data7 = large_list[6]
    data8 = large_list[7]
    data9 = large_list[8]



    # 箱型图名称
    labels = ["EN", "ZH_MT", "ZH_HT"]
    # 三个箱型图的颜色 RGB （均为0~1的数据）
    colors = [(202 / 255., 96 / 255., 17 / 255.), (255 / 255., 217 / 255., 102 / 255.),
              (137 / 255., 128 / 255., 68 / 255.)]
    # 绘制箱型图
    # patch_artist=True-->箱型可以更换颜色，positions=(1,1.4,1.8)-->将同一组的三个箱间隔设置为0.4，widths=0.3-->每个箱宽度为0.3
    bplot1 = plt.boxplot(data1, patch_artist=True, labels=labels, positions=(1, 1.4, 1.8), widths=0.3)
    for patch, color in zip(bplot1['boxes'], colors):
        patch.set_facecolor(color)

    bplot2 = plt.boxplot(data2, patch_artist=True, labels=labels, positions=(2.5, 2.9, 3.3), widths=0.3)
    for patch, color in zip(bplot2['boxes'], colors):
        patch.set_facecolor(color)

    bplot3 = plt.boxplot(data3, patch_artist=True, labels=labels, positions=(4, 4.4, 4.8), widths=0.3)
    for patch, color in zip(bplot3['boxes'], colors):
        patch.set_facecolor(color)

    bplot4 = plt.boxplot(data4, patch_artist=True, labels=labels, positions=(5.5, 5.9, 6.3), widths=0.3)
    for patch, color in zip(bplot4['boxes'], colors):
        patch.set_facecolor(color)

    bplot5 = plt.boxplot(data5, patch_artist=True, labels=labels, positions=(7, 7.4, 7.8), widths=0.3)
    for patch, color in zip(bplot5['boxes'], colors):
        patch.set_facecolor(color)

    bplot6 = plt.boxplot(data6, patch_artist=True, labels=labels, positions=(8.5, 8.9, 9.3), widths=0.3)
    for patch, color in zip(bplot6['boxes'], colors):
        patch.set_facecolor(color)

    bplot7 = plt.boxplot(data7, patch_artist=True, labels=labels, positions=(10, 10.4, 10.8), widths=0.3)
    for patch, color in zip(bplot7['boxes'], colors):
        patch.set_facecolor(color)

    bplot8 = plt.boxplot(data8, patch_artist=True, labels=labels, positions=(11.5, 11.9, 12.3), widths=0.3)
    for patch, color in zip(bplot8['boxes'], colors):
        patch.set_facecolor(color)

    bplot9 = plt.boxplot(data9, patch_artist=True, labels=labels, positions=(13, 13.4, 13.8), widths=0.3)
    for patch, color in zip(bplot9['boxes'], colors):
        patch.set_facecolor(color)


    x_position = [1, 2.5, 4,5.5,7,8.5,10,11.5,13]
    x_position_fmt = ['education', 'laws', 'microblog', 'news', 'officialDoc', 'science', 'scientificArticle', 'spoken', 'subtitles']
    plt.xticks([i + 0.8 / 2 for i in x_position], x_position_fmt)


    plt.grid(linestyle="--", alpha=0.3)  # 绘制图中虚线 透明度0.3
    plt.legend(bplot1['boxes'], labels, loc='upper right')  # 绘制表示框，右下角绘制
    plt.savefig(fname="pic.png", figsize=[10, 10])
    plt.title('token/sentence')
    plt.show()


# box_plot(new_large_list)




