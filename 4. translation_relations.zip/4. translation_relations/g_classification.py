from f_crp import crp_list, spacy_crp, crp_pair, transrelation, go_through_directory
from a_comparison import index_align_str, aligned_whole_list
import os

MT_aln = sorted(go_through_directory("/Users/zhoujie/Desktop/MT_aln"))
HT_aln = sorted(go_through_directory("/Users/zhoujie/Desktop/HT_aln"))
MT_crp = sorted(go_through_directory("/Users/zhoujie/Desktop/MT_crp"))
HT_crp = sorted(go_through_directory("/Users/zhoujie/Desktop/HT_crp"))

def overall_spacy(trans_aln, trans_crp):
    dict_pos = {}
    dict_dep = {}
    for aln,crp in zip(MT_aln, MT_crp):
        en_list, zh_list_MT = crp_list(crp)
        en_list_pos, zh_list_pos, en_list_tag, zh_list_tag, en_list_dep, zh_list_dep = spacy_crp(crp)
        list_all_pos_MT, list_all_dep_MT = crp_pair(aln, crp)
        transrelation_dict_pos_MT, transrelation_dict_dep_MT = transrelation(list_all_pos_MT, list_all_dep_MT)
        for k, v in transrelation_dict_pos_MT.items():
            if k not in dict_pos:
                dict_pos[k] = v
            else:
                dict_pos[k] += v
        for k, v in transrelation_dict_dep_MT.items():
            if k not in dict_dep:
                dict_dep[k] = v
            else:
                dict_dep[k] += v
    return dict_pos, dict_dep
MT_overall_dict_pos, MT_overall_dict_dep = overall_spacy(MT_aln, MT_crp)
HT_overall_dict_pos, HT_overall_dict_dep = overall_spacy(HT_aln, HT_crp)
# print(MT_overall_dict_pos)
# print(HT_overall_dict_pos)
# print(MT_overall_dict_dep)
# print(HT_overall_dict_dep)

# def top_20(over_dict):
#     for k, v in over_dict.items():
#         for




